// Cookie Banner Functionality
document.addEventListener("DOMContentLoaded", () => {
  const cookieBanner = document.getElementById("cookieBanner")
  const acceptBtn = document.getElementById("acceptCookies")
  const declineBtn = document.getElementById("declineCookies")

  // Always show cookie banner on page load (as per requirements)
  cookieBanner.classList.add("show")

  // Accept cookies
  acceptBtn.addEventListener("click", () => {
    cookieBanner.classList.remove("show")
    // In a real implementation, you would set a cookie here
    console.log("Cookies accepted")
  })

  // Decline cookies
  declineBtn.addEventListener("click", () => {
    cookieBanner.classList.remove("show")
    // In a real implementation, you would handle declined cookies
    console.log("Cookies declined")
  })

  // Mobile Navigation Toggle
  const navToggle = document.getElementById("navToggle")
  const navMenu = document.getElementById("navMenu")

  if (navToggle) {
    navToggle.addEventListener("click", () => {
      navMenu.classList.toggle("active")
    })
  }

  // Newsletter Form
  const newsletterForm = document.getElementById("newsletterForm")
  if (newsletterForm) {
    newsletterForm.addEventListener("submit", function (e) {
      e.preventDefault()
      const email = this.querySelector('input[type="email"]').value
      alert("Thank you for subscribing! We'll send updates to: " + email)
      this.reset()
    })
  }
})
