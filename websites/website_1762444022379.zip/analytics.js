// Analytics Chart Functionality
document.addEventListener("DOMContentLoaded", () => {
  const canvas = document.getElementById("bookingChart")
  if (!canvas) return

  const ctx = canvas.getContext("2d")

  // Set canvas size
  canvas.width = canvas.offsetWidth
  canvas.height = 300

  // Data
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
  const data = [65, 72, 81, 88, 95, 102, 118, 125, 115, 108, 98, 92]

  const padding = 40
  const chartWidth = canvas.width - padding * 2
  const chartHeight = canvas.height - padding * 2
  const maxValue = Math.max(...data)
  const barWidth = chartWidth / data.length

  // Draw axes
  ctx.strokeStyle = "#e2e8f0"
  ctx.lineWidth = 2
  ctx.beginPath()
  ctx.moveTo(padding, padding)
  ctx.lineTo(padding, canvas.height - padding)
  ctx.lineTo(canvas.width - padding, canvas.height - padding)
  ctx.stroke()

  // Draw bars
  data.forEach((value, index) => {
    const barHeight = (value / maxValue) * chartHeight
    const x = padding + index * barWidth + barWidth * 0.2
    const y = canvas.height - padding - barHeight
    const width = barWidth * 0.6

    // Gradient
    const gradient = ctx.createLinearGradient(0, y, 0, canvas.height - padding)
    gradient.addColorStop(0, "#3b82f6")
    gradient.addColorStop(1, "#0ea5e9")

    ctx.fillStyle = gradient
    ctx.fillRect(x, y, width, barHeight)

    // Month labels
    ctx.fillStyle = "#64748b"
    ctx.font = "12px sans-serif"
    ctx.textAlign = "center"
    ctx.fillText(months[index], x + width / 2, canvas.height - padding + 20)
  })

  // Animate metrics
  animateValue("bookingGrowth", 0, 24.5, 2000, "%", "+")
  animateValue("activeUsers", 0, 1.2, 2000, "M")
  animateValue("satisfaction", 0, 4.7, 2000, "/5")
  animateValue("destinations", 0, 156, 2000)
})

function animateValue(id, start, end, duration, suffix = "", prefix = "") {
  const element = document.getElementById(id)
  if (!element) return

  const range = end - start
  const increment = range / (duration / 16)
  let current = start

  const timer = setInterval(() => {
    current += increment
    if (current >= end) {
      current = end
      clearInterval(timer)
    }
    element.textContent = prefix + current.toFixed(1) + suffix
  }, 16)
}
