// Cookie Banner - Shows on every page load
document.addEventListener("DOMContentLoaded", () => {
  const cookieBanner = document.getElementById("cookieBanner")
  const acceptBtn = document.getElementById("acceptCookies")
  const declineBtn = document.getElementById("declineCookies")

  // Always show cookie banner on page load
  if (cookieBanner) {
    cookieBanner.classList.remove("hidden")
  }

  // Accept cookies
  if (acceptBtn) {
    acceptBtn.addEventListener("click", () => {
      cookieBanner.classList.add("hidden")
    })
  }

  // Decline cookies
  if (declineBtn) {
    declineBtn.addEventListener("click", () => {
      cookieBanner.classList.add("hidden")
    })
  }

  // Mobile menu toggle
  const menuToggle = document.getElementById("menuToggle")
  const mainNav = document.getElementById("mainNav")

  if (menuToggle && mainNav) {
    menuToggle.addEventListener("click", () => {
      mainNav.classList.toggle("active")
    })
  }

  // FAQ accordion
  const faqQuestions = document.querySelectorAll(".faq-question")
  faqQuestions.forEach((question) => {
    question.addEventListener("click", function () {
      const faqItem = this.parentElement
      const isActive = faqItem.classList.contains("active")

      // Close all FAQ items
      document.querySelectorAll(".faq-item").forEach((item) => {
        item.classList.remove("active")
      })

      // Open clicked item if it wasn't active
      if (!isActive) {
        faqItem.classList.add("active")
      }
    })
  })

  // Contact form submission
  const contactForm = document.getElementById("contactForm")
  if (contactForm) {
    contactForm.addEventListener("submit", (e) => {
      e.preventDefault()
      alert("Bedankt voor uw bericht! We nemen zo spoedig mogelijk contact met u op.")
      contactForm.reset()
    })
  }

  // Smooth scroll for anchor links
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault()
      const target = document.querySelector(this.getAttribute("href"))
      if (target) {
        target.scrollIntoView({
          behavior: "smooth",
          block: "start",
        })
      }
    })
  })
})
