// Mobile Menu Toggle
document.addEventListener("DOMContentLoaded", () => {
  const mobileMenuToggle = document.querySelector(".mobile-menu-toggle")
  const navMenu = document.querySelector(".nav-menu")

  if (mobileMenuToggle) {
    mobileMenuToggle.addEventListener("click", () => {
      navMenu.classList.toggle("active")
    })
  }

  // Close mobile menu when clicking on a link
  const navLinks = document.querySelectorAll(".nav-menu a")
  navLinks.forEach((link) => {
    link.addEventListener("click", () => {
      if (window.innerWidth <= 768) {
        navMenu.classList.remove("active")
      }
    })
  })

  // FAQ Accordion
  const faqQuestions = document.querySelectorAll(".faq-question")
  faqQuestions.forEach((question) => {
    question.addEventListener("click", function () {
      const faqItem = this.parentElement
      const isActive = faqItem.classList.contains("active")

      // Close all FAQ items
      document.querySelectorAll(".faq-item").forEach((item) => {
        item.classList.remove("active")
      })

      // Open clicked item if it wasn't active
      if (!isActive) {
        faqItem.classList.add("active")
      }
    })
  })

  // Cookie Banner Functionality
  showCookieBanner()

  const acceptCookiesBtn = document.getElementById("acceptCookies")
  const declineCookiesBtn = document.getElementById("declineCookies")

  if (acceptCookiesBtn) {
    acceptCookiesBtn.addEventListener("click", () => {
      setCookieConsent("accepted")
      hideCookieBanner()
    })
  }

  if (declineCookiesBtn) {
    declineCookiesBtn.addEventListener("click", () => {
      setCookieConsent("declined")
      hideCookieBanner()
    })
  }
})

// Cookie Banner Functions
function showCookieBanner() {
  // Always show banner on page load
  const cookieBanner = document.getElementById("cookieBanner")
  if (cookieBanner) {
    cookieBanner.classList.add("show")
  }
}

function hideCookieBanner() {
  const cookieBanner = document.getElementById("cookieBanner")
  if (cookieBanner) {
    cookieBanner.classList.remove("show")
  }
}

function setCookieConsent(status) {
  // Store consent status (in a real implementation, this would set actual cookies)
  console.log("Cookie consent: " + status)
  // You can add actual cookie setting logic here if needed
}

// Contact Form Handler
function handleContactForm(event) {
  event.preventDefault()

  const formData = new FormData(event.target)
  const data = Object.fromEntries(formData)

  // In a real implementation, you would send this data to a server
  console.log("Form submitted:", data)

  // Show success message
  alert("Thank you for your message! We will contact you shortly.")

  // Reset form
  event.target.reset()

  return false
}

// Smooth Scrolling for Anchor Links
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    e.preventDefault()
    const target = document.querySelector(this.getAttribute("href"))
    if (target) {
      target.scrollIntoView({
        behavior: "smooth",
        block: "start",
      })
    }
  })
})

// Add animation on scroll (optional enhancement)
const observerOptions = {
  threshold: 0.1,
  rootMargin: "0px 0px -50px 0px",
}

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = "1"
      entry.target.style.transform = "translateY(0)"
    }
  })
}, observerOptions)

// Observe elements for animation
document.addEventListener("DOMContentLoaded", () => {
  const animateElements = document.querySelectorAll(".feature-card, .value-card, .team-card, .resource-card")
  animateElements.forEach((el) => {
    el.style.opacity = "0"
    el.style.transform = "translateY(20px)"
    el.style.transition = "opacity 0.6s ease, transform 0.6s ease"
    observer.observe(el)
  })
})
