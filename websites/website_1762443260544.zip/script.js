// Cookie Banner Functionality
document.addEventListener("DOMContentLoaded", () => {
  const cookieBanner = document.getElementById("cookieBanner")
  const acceptBtn = document.getElementById("acceptCookies")
  const declineBtn = document.getElementById("declineCookies")

  // Always show cookie banner on page load
  cookieBanner.classList.add("show")

  // Accept cookies
  acceptBtn.addEventListener("click", () => {
    cookieBanner.classList.remove("show")
    localStorage.setItem("cookieConsent", "accepted")
  })

  // Decline cookies
  declineBtn.addEventListener("click", () => {
    cookieBanner.classList.remove("show")
    localStorage.setItem("cookieConsent", "declined")
  })

  // Mobile Menu Toggle
  const mobileMenuToggle = document.getElementById("mobileMenuToggle")
  const navMenu = document.getElementById("navMenu")

  if (mobileMenuToggle) {
    mobileMenuToggle.addEventListener("click", () => {
      navMenu.classList.toggle("active")
    })
  }

  // Animated Counter for Stats
  const statNumbers = document.querySelectorAll(".stat-number")

  const animateCounter = (element) => {
    const target = Number.parseInt(element.getAttribute("data-target"))
    const duration = 2000
    const increment = target / (duration / 16)
    let current = 0

    const updateCounter = () => {
      current += increment
      if (current < target) {
        element.textContent = Math.floor(current)
        requestAnimationFrame(updateCounter)
      } else {
        element.textContent = target
      }
    }

    updateCounter()
  }

  // Intersection Observer for Stats Animation
  const statsObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          animateCounter(entry.target)
          statsObserver.unobserve(entry.target)
        }
      })
    },
    { threshold: 0.5 },
  )

  statNumbers.forEach((stat) => {
    statsObserver.observe(stat)
  })

  // Chart for Data Visualization (Simple Canvas Chart)
  const chartCanvas = document.getElementById("trendChart")

  if (chartCanvas) {
    const ctx = chartCanvas.getContext("2d")
    const width = chartCanvas.parentElement.offsetWidth
    const height = 400

    chartCanvas.width = width
    chartCanvas.height = height

    // Sample data
    const data = [65, 72, 78, 85, 92, 88, 95]
    const labels = ["2018", "2019", "2020", "2021", "2022", "2023", "2024"]

    const padding = 60
    const chartWidth = width - padding * 2
    const chartHeight = height - padding * 2
    const maxValue = Math.max(...data)

    // Draw axes
    ctx.strokeStyle = "#657786"
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(padding, padding)
    ctx.lineTo(padding, height - padding)
    ctx.lineTo(width - padding, height - padding)
    ctx.stroke()

    // Draw grid lines
    ctx.strokeStyle = "#E1E8ED"
    ctx.lineWidth = 1
    for (let i = 0; i <= 5; i++) {
      const y = padding + (chartHeight / 5) * i
      ctx.beginPath()
      ctx.moveTo(padding, y)
      ctx.lineTo(width - padding, y)
      ctx.stroke()
    }

    // Draw data line
    ctx.strokeStyle = "#4A90E2"
    ctx.lineWidth = 3
    ctx.beginPath()

    data.forEach((value, index) => {
      const x = padding + (chartWidth / (data.length - 1)) * index
      const y = height - padding - (value / maxValue) * chartHeight

      if (index === 0) {
        ctx.moveTo(x, y)
      } else {
        ctx.lineTo(x, y)
      }
    })

    ctx.stroke()

    // Draw data points
    data.forEach((value, index) => {
      const x = padding + (chartWidth / (data.length - 1)) * index
      const y = height - padding - (value / maxValue) * chartHeight

      ctx.fillStyle = "#2D5F3F"
      ctx.beginPath()
      ctx.arc(x, y, 6, 0, Math.PI * 2)
      ctx.fill()
    })

    // Draw labels
    ctx.fillStyle = "#1C2833"
    ctx.font = "14px sans-serif"
    ctx.textAlign = "center"

    labels.forEach((label, index) => {
      const x = padding + (chartWidth / (data.length - 1)) * index
      ctx.fillText(label, x, height - padding + 25)
    })

    // Draw title
    ctx.font = "bold 16px sans-serif"
    ctx.fillText("Technology Adoption Rate (%)", width / 2, 30)
  }

  // Filter functionality for articles page
  const filterButtons = document.querySelectorAll(".filter-btn")
  const articleCards = document.querySelectorAll(".article-card")

  filterButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const filter = this.getAttribute("data-filter")

      // Update active button
      filterButtons.forEach((btn) => btn.classList.remove("active"))
      this.classList.add("active")

      // Filter articles
      articleCards.forEach((card) => {
        if (filter === "all" || card.getAttribute("data-category") === filter) {
          card.style.display = "block"
        } else {
          card.style.display = "none"
        }
      })
    })
  })

  // FAQ Accordion
  const faqQuestions = document.querySelectorAll(".faq-question")

  faqQuestions.forEach((question) => {
    question.addEventListener("click", function () {
      const faqItem = this.parentElement
      const isActive = faqItem.classList.contains("active")

      // Close all FAQ items
      document.querySelectorAll(".faq-item").forEach((item) => {
        item.classList.remove("active")
      })

      // Open clicked item if it wasn't active
      if (!isActive) {
        faqItem.classList.add("active")
      }
    })
  })

  // Newsletter Form
  const newsletterForm = document.getElementById("newsletterForm")

  if (newsletterForm) {
    newsletterForm.addEventListener("submit", function (e) {
      e.preventDefault()
      const email = this.querySelector('input[type="email"]').value
      alert("Thank you for subscribing! We'll send updates to " + email)
      this.reset()
    })
  }

  // Smooth scroll for anchor links
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      const href = this.getAttribute("href")
      if (href !== "#" && href.length > 1) {
        e.preventDefault()
        const target = document.querySelector(href)
        if (target) {
          target.scrollIntoView({
            behavior: "smooth",
            block: "start",
          })
        }
      }
    })
  })
})
