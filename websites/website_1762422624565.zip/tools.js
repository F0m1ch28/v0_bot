// Tools Modal Management
function openTool(toolType) {
  const modal = document.getElementById("toolModal")
  const toolContent = document.getElementById("toolContent")

  let content = ""

  switch (toolType) {
    case "budget":
      content = `
                <h2>Budgetplaner</h2>
                <div class="tool-interface">
                    <div class="input-group">
                        <label>Monatliches Einkommen (€)</label>
                        <input type="number" id="toolIncome" placeholder="3000" value="3000">
                    </div>
                    <div class="input-group">
                        <label>Wohnung/Miete (€)</label>
                        <input type="number" id="toolRent" placeholder="800" value="800">
                    </div>
                    <div class="input-group">
                        <label>Lebensmittel (€)</label>
                        <input type="number" id="toolFood" placeholder="400" value="400">
                    </div>
                    <div class="input-group">
                        <label>Transport (€)</label>
                        <input type="number" id="toolTransport" placeholder="150" value="150">
                    </div>
                    <div class="input-group">
                        <label>Sonstiges (€)</label>
                        <input type="number" id="toolOther" placeholder="300" value="300">
                    </div>
                    <div class="result-card" style="margin-top: 2rem;">
                        <h3>Verfügbar</h3>
                        <div class="result-amount" id="toolResult">1350 €</div>
                    </div>
                </div>
            `
      break
    case "savings":
      content = `
                <h2>Sparrechner</h2>
                <div class="tool-interface">
                    <div class="input-group">
                        <label>Monatlicher Sparbetrag (€)</label>
                        <input type="number" id="savingsAmount" placeholder="500" value="500">
                    </div>
                    <div class="input-group">
                        <label>Zeitraum (Monate)</label>
                        <input type="number" id="savingsMonths" placeholder="12" value="12">
                    </div>
                    <div class="input-group">
                        <label>Jährlicher Zinssatz (%)</label>
                        <input type="number" id="savingsRate" placeholder="2" value="2" step="0.1">
                    </div>
                    <div class="result-card" style="margin-top: 2rem;">
                        <h3>Gesamtersparnis nach <span id="monthsDisplay">12</span> Monaten</h3>
                        <div class="result-amount" id="savingsResult">6060 €</div>
                        <p style="margin-top: 1rem; color: var(--color-text-light);">
                            Davon Zinsen: <strong id="interestAmount">60 €</strong>
                        </p>
                    </div>
                </div>
            `
      break
    case "expenses":
      content = `
                <h2>Ausgabentracker</h2>
                <div class="tool-interface">
                    <div class="input-group">
                        <label>Ausgabenkategorie</label>
                        <select id="expenseCategory" style="padding: 0.75rem; border: 2px solid var(--color-border); border-radius: var(--border-radius); font-size: 1rem;">
                            <option>Lebensmittel</option>
                            <option>Transport</option>
                            <option>Unterhaltung</option>
                            <option>Gesundheit</option>
                            <option>Sonstiges</option>
                        </select>
                    </div>
                    <div class="input-group">
                        <label>Betrag (€)</label>
                        <input type="number" id="expenseAmount" placeholder="50">
                    </div>
                    <button class="tool-btn" onclick="addExpense()">Ausgabe hinzufügen</button>
                    <div style="margin-top: 2rem;">
                        <h3>Heutige Ausgaben</h3>
                        <div id="expenseList" style="margin-top: 1rem;">
                            <p style="color: var(--color-text-light);">Noch keine Ausgaben erfasst</p>
                        </div>
                        <div class="result-card" style="margin-top: 1rem;">
                            <h3>Gesamt heute</h3>
                            <div class="result-amount" id="expenseTotal">0 €</div>
                        </div>
                    </div>
                </div>
            `
      break
    case "goals":
      content = `
                <h2>Zielplaner</h2>
                <div class="tool-interface">
                    <div class="input-group">
                        <label>Zielname</label>
                        <input type="text" id="goalName" placeholder="z.B. Urlaub, Auto, Notfallfonds">
                    </div>
                    <div class="input-group">
                        <label>Zielbetrag (€)</label>
                        <input type="number" id="goalAmount" placeholder="5000" value="5000">
                    </div>
                    <div class="input-group">
                        <label>Bereits gespart (€)</label>
                        <input type="number" id="goalSaved" placeholder="1000" value="1000">
                    </div>
                    <div class="input-group">
                        <label>Monatlicher Sparbetrag (€)</label>
                        <input type="number" id="goalMonthly" placeholder="500" value="500">
                    </div>
                    <div class="result-card" style="margin-top: 2rem;">
                        <h3>Zeit bis zum Ziel</h3>
                        <div class="result-amount" id="goalMonths">8 Monate</div>
                        <div class="progress-bar" style="margin-top: 1rem;">
                            <div class="progress-fill" id="goalProgress" style="width: 20%"></div>
                        </div>
                        <p style="margin-top: 1rem; color: var(--color-text-light);">
                            Fortschritt: <strong id="goalPercent">20%</strong>
                        </p>
                    </div>
                </div>
            `
      break
  }

  toolContent.innerHTML = content
  modal.classList.add("show")

  // Add event listeners for the specific tool
  setTimeout(() => {
    if (toolType === "budget") {
      setupBudgetTool()
    } else if (toolType === "savings") {
      setupSavingsTool()
    } else if (toolType === "goals") {
      setupGoalsTool()
    }
  }, 100)
}

function closeTool() {
  const modal = document.getElementById("toolModal")
  modal.classList.remove("show")
}

// Budget Tool
function setupBudgetTool() {
  const inputs = ["toolIncome", "toolRent", "toolFood", "toolTransport", "toolOther"]

  function calculate() {
    const income = Number.parseFloat(document.getElementById("toolIncome").value) || 0
    const rent = Number.parseFloat(document.getElementById("toolRent").value) || 0
    const food = Number.parseFloat(document.getElementById("toolFood").value) || 0
    const transport = Number.parseFloat(document.getElementById("toolTransport").value) || 0
    const other = Number.parseFloat(document.getElementById("toolOther").value) || 0

    const available = income - rent - food - transport - other
    document.getElementById("toolResult").textContent = available.toFixed(0) + " €"
  }

  inputs.forEach((id) => {
    const input = document.getElementById(id)
    if (input) {
      input.addEventListener("input", calculate)
    }
  })

  calculate()
}

// Savings Tool
function setupSavingsTool() {
  const amountInput = document.getElementById("savingsAmount")
  const monthsInput = document.getElementById("savingsMonths")
  const rateInput = document.getElementById("savingsRate")

  function calculate() {
    const monthly = Number.parseFloat(amountInput.value) || 0
    const months = Number.parseFloat(monthsInput.value) || 0
    const rate = Number.parseFloat(rateInput.value) || 0

    const principal = monthly * months
    const interest = ((principal * rate) / 100) * (months / 12)
    const total = principal + interest

    document.getElementById("monthsDisplay").textContent = months
    document.getElementById("savingsResult").textContent = total.toFixed(0) + " €"
    document.getElementById("interestAmount").textContent = interest.toFixed(0) + " €"
  }

  amountInput.addEventListener("input", calculate)
  monthsInput.addEventListener("input", calculate)
  rateInput.addEventListener("input", calculate)

  calculate()
}

// Goals Tool
function setupGoalsTool() {
  const inputs = ["goalAmount", "goalSaved", "goalMonthly"]

  function calculate() {
    const target = Number.parseFloat(document.getElementById("goalAmount").value) || 0
    const saved = Number.parseFloat(document.getElementById("goalSaved").value) || 0
    const monthly = Number.parseFloat(document.getElementById("goalMonthly").value) || 0

    const remaining = target - saved
    const months = monthly > 0 ? Math.ceil(remaining / monthly) : 0
    const percent = target > 0 ? ((saved / target) * 100).toFixed(0) : 0

    document.getElementById("goalMonths").textContent = months + " Monate"
    document.getElementById("goalProgress").style.width = percent + "%"
    document.getElementById("goalPercent").textContent = percent + "%"
  }

  inputs.forEach((id) => {
    const input = document.getElementById(id)
    if (input) {
      input.addEventListener("input", calculate)
    }
  })

  calculate()
}

// Expense Tracker
const expenses = []

function addExpense() {
  const category = document.getElementById("expenseCategory").value
  const amount = Number.parseFloat(document.getElementById("expenseAmount").value)

  if (!amount || amount <= 0) {
    alert("Bitte geben Sie einen gültigen Betrag ein")
    return
  }

  expenses.push({ category, amount })
  updateExpenseList()
  document.getElementById("expenseAmount").value = ""
}

function updateExpenseList() {
  const list = document.getElementById("expenseList")
  const total = expenses.reduce((sum, exp) => sum + exp.amount, 0)

  if (expenses.length === 0) {
    list.innerHTML = '<p style="color: var(--color-text-light);">Noch keine Ausgaben erfasst</p>'
  } else {
    list.innerHTML = expenses
      .map(
        (exp, index) => `
            <div style="display: flex; justify-content: space-between; padding: 0.5rem; background: var(--color-background); margin-bottom: 0.5rem; border-radius: 4px;">
                <span>${exp.category}</span>
                <strong>${exp.amount.toFixed(2)} €</strong>
            </div>
        `,
      )
      .join("")
  }

  document.getElementById("expenseTotal").textContent = total.toFixed(2) + " €"
}

// Close modal when clicking outside
document.addEventListener("click", (e) => {
  const modal = document.getElementById("toolModal")
  if (e.target === modal) {
    closeTool()
  }
})
