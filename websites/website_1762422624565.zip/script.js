// Cookie Banner Management
document.addEventListener("DOMContentLoaded", () => {
  const cookieBanner = document.getElementById("cookieBanner")
  const acceptBtn = document.getElementById("acceptCookies")
  const declineBtn = document.getElementById("declineCookies")

  // Always show cookie banner on page load
  cookieBanner.classList.add("show")

  acceptBtn.addEventListener("click", () => {
    cookieBanner.classList.remove("show")
  })

  declineBtn.addEventListener("click", () => {
    cookieBanner.classList.remove("show")
  })

  // Mobile Navigation Toggle
  const mobileToggle = document.getElementById("mobileToggle")
  const navMenu = document.getElementById("navMenu")

  if (mobileToggle) {
    mobileToggle.addEventListener("click", () => {
      navMenu.classList.toggle("active")
    })
  }

  // Budget Calculator
  const incomeInput = document.getElementById("income")
  const expensesInput = document.getElementById("expenses")
  const savingsInput = document.getElementById("savings")
  const availableDisplay = document.getElementById("available")
  const statusDisplay = document.getElementById("status")
  const progressFill = document.getElementById("progressFill")

  function calculateBudget() {
    if (!incomeInput || !expensesInput || !savingsInput) return

    const income = Number.parseFloat(incomeInput.value) || 0
    const expenses = Number.parseFloat(expensesInput.value) || 0
    const savingsGoal = Number.parseFloat(savingsInput.value) || 0

    const available = income - expenses
    availableDisplay.textContent = available.toFixed(0) + " €"

    if (available >= savingsGoal) {
      statusDisplay.textContent = "Sie erreichen Ihr Sparziel!"
      statusDisplay.style.color = "var(--color-accent)"
    } else if (available > 0) {
      statusDisplay.textContent = "Fast geschafft! Noch " + (savingsGoal - available).toFixed(0) + " € bis zum Ziel."
      statusDisplay.style.color = "var(--color-text-light)"
    } else {
      statusDisplay.textContent = "Ausgaben übersteigen Einkommen"
      statusDisplay.style.color = "#d63031"
    }

    const progressPercent = savingsGoal > 0 ? Math.min((available / savingsGoal) * 100, 100) : 0
    progressFill.style.width = progressPercent + "%"
  }

  if (incomeInput) {
    incomeInput.addEventListener("input", calculateBudget)
    expensesInput.addEventListener("input", calculateBudget)
    savingsInput.addEventListener("input", calculateBudget)
    calculateBudget()
  }

  // Smooth Scroll
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault()
      const target = document.querySelector(this.getAttribute("href"))
      if (target) {
        target.scrollIntoView({
          behavior: "smooth",
          block: "start",
        })
      }
    })
  })
})
