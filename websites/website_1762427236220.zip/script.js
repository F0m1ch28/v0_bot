// Cookie Banner Functions
function showCookieBanner() {
  const banner = document.getElementById("cookieBanner")
  if (banner) {
    banner.style.display = "block"
  }
}

function acceptCookies() {
  const banner = document.getElementById("cookieBanner")
  if (banner) {
    banner.style.animation = "slideDown 0.5s ease-out"
    setTimeout(() => {
      banner.style.display = "none"
    }, 500)
  }
}

function declineCookies() {
  const banner = document.getElementById("cookieBanner")
  if (banner) {
    banner.style.animation = "slideDown 0.5s ease-out"
    setTimeout(() => {
      banner.style.display = "none"
    }, 500)
  }
}

// Add slide down animation
const style = document.createElement("style")
style.textContent = `
    @keyframes slideDown {
        from {
            transform: translateY(0);
        }
        to {
            transform: translateY(100%);
        }
    }
`
document.head.appendChild(style)

// Show cookie banner on page load
window.addEventListener("load", () => {
  showCookieBanner()
})

// Mobile Menu Toggle
function toggleMobileMenu() {
  const mobileNav = document.getElementById("mobileNav")
  mobileNav.classList.toggle("active")
}

// Newsletter Form Handler
function handleNewsletter(event) {
  event.preventDefault()
  const email = event.target.querySelector('input[type="email"]').value
  alert(`Thank you for subscribing! We'll send updates to ${email}`)
  event.target.reset()
}

// Smooth Scroll for Anchor Links
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    e.preventDefault()
    const target = document.querySelector(this.getAttribute("href"))
    if (target) {
      target.scrollIntoView({
        behavior: "smooth",
        block: "start",
      })
    }
  })
})

// Add animation on scroll
const observerOptions = {
  threshold: 0.1,
  rootMargin: "0px 0px -50px 0px",
}

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = "1"
      entry.target.style.transform = "translateY(0)"
    }
  })
}, observerOptions)

// Observe news cards for animation
document.addEventListener("DOMContentLoaded", () => {
  const cards = document.querySelectorAll(".news-card")
  cards.forEach((card) => {
    card.style.opacity = "0"
    card.style.transform = "translateY(20px)"
    card.style.transition = "opacity 0.6s ease, transform 0.6s ease"
    observer.observe(card)
  })
})
