// Products Data
const products = [
  {
    id: 1,
    name: "Смартфон iPhone 15 Pro",
    price: 89990,
    category: "smartphones",
    image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&h=300&fit=crop",
    description: "Новейший флагманский смартфон от Apple с процессором A17 Pro",
  },
  {
    id: 2,
    name: "Samsung Galaxy S24 Ultra",
    price: 79990,
    category: "smartphones",
    image: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?w=400&h=300&fit=crop",
    description: "Премиальный Android-смартфон с передовыми функциями",
  },
  {
    id: 3,
    name: 'MacBook Pro 14"',
    price: 149990,
    category: "laptops",
    image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&h=300&fit=crop",
    description: "Мощный ноутбук для профессиональной работы",
  },
  {
    id: 4,
    name: "Dell XPS 15",
    price: 119990,
    category: "laptops",
    image: "https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=400&h=300&fit=crop",
    description: "Производительный ноутбук с превосходным дисплеем",
  },
  {
    id: 5,
    name: 'iPad Pro 12.9"',
    price: 99990,
    category: "tablets",
    image: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400&h=300&fit=crop",
    description: "Профессиональный планшет с процессором M2",
  },
  {
    id: 6,
    name: "Samsung Galaxy Tab S9",
    price: 69990,
    category: "tablets",
    image: "https://images.unsplash.com/photo-1585790050230-5dd28404f1b4?w=400&h=300&fit=crop",
    description: "Премиальный Android-планшет для работы и развлечений",
  },
  {
    id: 7,
    name: "AirPods Pro 2",
    price: 24990,
    category: "accessories",
    image: "https://images.unsplash.com/photo-1606841837239-c5a1a4a07af7?w=400&h=300&fit=crop",
    description: "Беспроводные наушники с активным шумоподавлением",
  },
  {
    id: 8,
    name: "Apple Watch Series 9",
    price: 39990,
    category: "accessories",
    image: "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=400&h=300&fit=crop",
    description: "Умные часы с расширенными функциями здоровья",
  },
  {
    id: 9,
    name: "Sony WH-1000XM5",
    price: 29990,
    category: "accessories",
    image: "https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=400&h=300&fit=crop",
    description: "Премиальные наушники с лучшим шумоподавлением",
  },
  {
    id: 10,
    name: "Xiaomi 13 Pro",
    price: 59990,
    category: "smartphones",
    image: "https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=400&h=300&fit=crop",
    description: "Флагманский смартфон с отличной камерой",
  },
  {
    id: 11,
    name: "Lenovo ThinkPad X1",
    price: 139990,
    category: "laptops",
    image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400&h=300&fit=crop",
    description: "Бизнес-ноутбук с надежностью и производительностью",
  },
  {
    id: 12,
    name: "Microsoft Surface Pro 9",
    price: 89990,
    category: "tablets",
    image: "https://images.unsplash.com/photo-1587033411391-5d9e51cce126?w=400&h=300&fit=crop",
    description: "Универсальный планшет-трансформер для работы",
  },
]

// Cart Management
let cart = JSON.parse(localStorage.getItem("cart")) || []

function updateCartCount() {
  const cartCount = document.getElementById("cartCount")
  if (cartCount) {
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0)
    cartCount.textContent = totalItems
  }
}

function addToCart(productId) {
  const product = products.find((p) => p.id === productId)
  const existingItem = cart.find((item) => item.id === productId)

  if (existingItem) {
    existingItem.quantity += 1
  } else {
    cart.push({ ...product, quantity: 1 })
  }

  localStorage.setItem("cart", JSON.stringify(cart))
  updateCartCount()
  alert("Товар добавлен в корзину!")
}

function removeFromCart(productId) {
  cart = cart.filter((item) => item.id !== productId)
  localStorage.setItem("cart", JSON.stringify(cart))
  updateCartCount()
  renderCart()
}

function updateQuantity(productId, change) {
  const item = cart.find((item) => item.id === productId)
  if (item) {
    item.quantity += change
    if (item.quantity <= 0) {
      removeFromCart(productId)
    } else {
      localStorage.setItem("cart", JSON.stringify(cart))
      updateCartCount()
      renderCart()
    }
  }
}

function getCartTotal() {
  return cart.reduce((sum, item) => sum + item.price * item.quantity, 0)
}

// Render Products
function renderProducts(productsToRender, containerId) {
  const container = document.getElementById(containerId)
  if (!container) return

  container.innerHTML = productsToRender
    .map(
      (product) => `
        <div class="product-card" onclick="window.location.href='product.html?id=${product.id}'">
            <img src="${product.image}" alt="${product.name}" class="product-image">
            <div class="product-info">
                <h3 class="product-name">${product.name}</h3>
                <p class="product-description">${product.description}</p>
                <div class="product-footer">
                    <span class="product-price">${product.price.toLocaleString("ru-RU")} ₽</span>
                    <button class="add-to-cart-btn" onclick="event.stopPropagation(); addToCart(${product.id})">
                        В корзину
                    </button>
                </div>
            </div>
        </div>
    `,
    )
    .join("")
}

// Render Cart
function renderCart() {
  const cartContent = document.getElementById("cartContent")
  if (!cartContent) return

  if (cart.length === 0) {
    cartContent.innerHTML = `
            <div class="empty-cart">
                <h2>Корзина пуста</h2>
                <p>Добавьте товары из каталога</p>
                <a href="catalog.html" class="btn btn-primary">Перейти в каталог</a>
            </div>
        `
    return
  }

  const total = getCartTotal()

  cartContent.innerHTML = `
        <div class="cart-items">
            ${cart
              .map(
                (item) => `
                <div class="cart-item">
                    <img src="${item.image}" alt="${item.name}" class="cart-item-image">
                    <div class="cart-item-info">
                        <h3 class="cart-item-name">${item.name}</h3>
                        <p class="cart-item-price">${item.price.toLocaleString("ru-RU")} ₽</p>
                        <div class="cart-item-controls">
                            <button class="quantity-btn" onclick="updateQuantity(${item.id}, -1)">-</button>
                            <span>${item.quantity}</span>
                            <button class="quantity-btn" onclick="updateQuantity(${item.id}, 1)">+</button>
                        </div>
                    </div>
                    <button class="remove-btn" onclick="removeFromCart(${item.id})">Удалить</button>
                </div>
            `,
              )
              .join("")}
        </div>
        <div class="cart-summary">
            <h3>Итого</h3>
            <div class="summary-row">
                <span>Товары:</span>
                <span>${total.toLocaleString("ru-RU")} ₽</span>
            </div>
            <div class="summary-row">
                <span>Доставка:</span>
                <span>${total >= 3000 ? "Бесплатно" : "500 ₽"}</span>
            </div>
            <div class="summary-row total">
                <span>Всего:</span>
                <span>${(total + (total >= 3000 ? 0 : 500)).toLocaleString("ru-RU")} ₽</span>
            </div>
            <button class="btn btn-primary btn-block" onclick="window.location.href='checkout.html'">
                Оформить заказ
            </button>
        </div>
    `
}

// Render Product Details
function renderProductDetail() {
  const urlParams = new URLSearchParams(window.location.search)
  const productId = Number.parseInt(urlParams.get("id"))
  const product = products.find((p) => p.id === productId)

  if (!product) {
    window.location.href = "catalog.html"
    return
  }

  const container = document.getElementById("productDetail")
  const breadcrumbName = document.getElementById("productName")

  if (breadcrumbName) {
    breadcrumbName.textContent = product.name
  }

  if (container) {
    container.innerHTML = `
            <div>
                <img src="${product.image}" alt="${product.name}" class="product-detail-image">
            </div>
            <div class="product-detail-info">
                <h1>${product.name}</h1>
                <div class="product-detail-price">${product.price.toLocaleString("ru-RU")} ₽</div>
                <p>${product.description}</p>
                
                <div class="product-specs">
                    <h3>Характеристики:</h3>
                    <ul>
                        <li>✅ Официальная гарантия 12 месяцев</li>
                        <li>✅ Бесплатная доставка от 3000 ₽</li>
                        <li>✅ Возврат в течение 14 дней</li>
                        <li>✅ Оригинальная продукция</li>
                    </ul>
                </div>
                
                <button class="btn btn-primary btn-block" onclick="addToCart(${product.id})">
                    Добавить в корзину
                </button>
            </div>
        `
  }
}

// Filter Products
function filterProducts() {
  const category = document.getElementById("categoryFilter").value
  const sort = document.getElementById("sortFilter").value

  const filtered = category === "all" ? [...products] : products.filter((p) => p.category === category)

  switch (sort) {
    case "price-asc":
      filtered.sort((a, b) => a.price - b.price)
      break
    case "price-desc":
      filtered.sort((a, b) => b.price - a.price)
      break
    case "name":
      filtered.sort((a, b) => a.name.localeCompare(b.name))
      break
  }

  renderProducts(filtered, "catalogProducts")
}

// Render Checkout
function renderCheckout() {
  const checkoutItems = document.getElementById("checkoutItems")
  if (!checkoutItems) return

  if (cart.length === 0) {
    window.location.href = "cart.html"
    return
  }

  const total = getCartTotal()
  const deliveryFee = total >= 3000 ? 0 : 500

  checkoutItems.innerHTML = `
        ${cart
          .map(
            (item) => `
            <div class="summary-row">
                <span>${item.name} × ${item.quantity}</span>
                <span>${(item.price * item.quantity).toLocaleString("ru-RU")} ₽</span>
            </div>
        `,
          )
          .join("")}
        <div class="summary-row">
            <span>Доставка:</span>
            <span>${deliveryFee === 0 ? "Бесплатно" : "500 ₽"}</span>
        </div>
        <div class="summary-row total">
            <span>Итого:</span>
            <span>${(total + deliveryFee).toLocaleString("ru-RU")} ₽</span>
        </div>
    `
}

// Handle Checkout Form
function handleCheckoutSubmit(e) {
  e.preventDefault()

  const orderNumber = "EM" + Date.now()
  document.getElementById("orderNumber").textContent = orderNumber

  // Clear cart
  cart = []
  localStorage.setItem("cart", JSON.stringify(cart))
  updateCartCount()

  // Show success modal
  document.getElementById("successModal").classList.add("active")
}

function closeModal() {
  document.getElementById("successModal").classList.remove("active")
  window.location.href = "index.html"
}

// Handle Contact Form
function handleContactSubmit(e) {
  e.preventDefault()
  document.getElementById("contactForm").style.display = "none"
  document.getElementById("contactSuccess").style.display = "block"
}

// FAQ Toggle
function toggleFaq(element) {
  const faqItem = element.parentElement
  faqItem.classList.toggle("active")
}

// Mobile Menu Toggle
function toggleMobileMenu() {
  const nav = document.getElementById("nav")
  nav.classList.toggle("active")
}

// Cookie Banner
function showCookieBanner() {
  const banner = document.getElementById("cookieBanner")
  if (banner) {
    banner.classList.add("show")
  }
}

function acceptCookies() {
  document.getElementById("cookieBanner").classList.remove("show")
}

function declineCookies() {
  document.getElementById("cookieBanner").classList.remove("show")
}

// Initialize
document.addEventListener("DOMContentLoaded", () => {
  // Update cart count on all pages
  updateCartCount()

  // Show cookie banner on every page load
  showCookieBanner()

  // Mobile menu
  const mobileMenuBtn = document.getElementById("mobileMenuBtn")
  if (mobileMenuBtn) {
    mobileMenuBtn.addEventListener("click", toggleMobileMenu)
  }

  // Home page
  if (document.getElementById("featuredProducts")) {
    renderProducts(products.slice(0, 6), "featuredProducts")
  }

  // Catalog page
  if (document.getElementById("catalogProducts")) {
    renderProducts(products, "catalogProducts")
  }

  // Product detail page
  if (document.getElementById("productDetail")) {
    renderProductDetail()
  }

  // Cart page
  if (document.getElementById("cartContent")) {
    renderCart()
  }

  // Checkout page
  if (document.getElementById("checkoutItems")) {
    renderCheckout()
    const checkoutForm = document.getElementById("checkoutForm")
    if (checkoutForm) {
      checkoutForm.addEventListener("submit", handleCheckoutSubmit)
    }
  }

  // Contact page
  const contactForm = document.getElementById("contactForm")
  if (contactForm) {
    contactForm.addEventListener("submit", handleContactSubmit)
  }
})
