// Mobile Menu Toggle
document.addEventListener("DOMContentLoaded", () => {
  const mobileMenuToggle = document.querySelector(".mobile-menu-toggle")
  const navMenu = document.querySelector(".nav-menu")

  if (mobileMenuToggle) {
    mobileMenuToggle.addEventListener("click", () => {
      navMenu.classList.toggle("active")
    })
  }

  // Close mobile menu when clicking outside
  document.addEventListener("click", (event) => {
    if (navMenu && navMenu.classList.contains("active")) {
      if (!event.target.closest(".nav-wrapper")) {
        navMenu.classList.remove("active")
      }
    }
  })

  // FAQ Accordion
  const faqQuestions = document.querySelectorAll(".faq-question")
  faqQuestions.forEach((question) => {
    question.addEventListener("click", function () {
      const faqItem = this.parentElement
      const isActive = faqItem.classList.contains("active")

      // Close all other FAQ items
      document.querySelectorAll(".faq-item").forEach((item) => {
        item.classList.remove("active")
      })

      // Toggle current item
      if (!isActive) {
        faqItem.classList.add("active")
      }
    })
  })

  // Contact Form Submission
  const contactForm = document.getElementById("contactForm")
  if (contactForm) {
    contactForm.addEventListener("submit", (e) => {
      e.preventDefault()

      const formMessage = document.getElementById("formMessage")
      const formData = new FormData(contactForm)

      // Simulate form submission (replace with actual submission logic)
      setTimeout(() => {
        formMessage.textContent = "Thank you for your message! We will get back to you soon."
        formMessage.className = "form-message success"
        contactForm.reset()

        // Hide success message after 5 seconds
        setTimeout(() => {
          formMessage.style.display = "none"
        }, 5000)
      }, 500)
    })
  }

  // Cookie Banner Management
  const cookieBanner = document.getElementById("cookieBanner")
  const acceptCookies = document.getElementById("acceptCookies")
  const declineCookies = document.getElementById("declineCookies")

  // Show cookie banner on every page load (as per requirements)
  function showCookieBanner() {
    cookieBanner.classList.add("show")
  }

  // Hide cookie banner
  function hideCookieBanner() {
    cookieBanner.classList.remove("show")
  }

  // Check if user has made a cookie choice for this session
  const cookieChoice = sessionStorage.getItem("cookieChoice")

  if (!cookieChoice) {
    // Show banner if no choice has been made
    showCookieBanner()
  }

  // Accept cookies
  acceptCookies.addEventListener("click", () => {
    sessionStorage.setItem("cookieChoice", "accepted")
    hideCookieBanner()
    console.log("Cookies accepted")
  })

  // Decline cookies
  declineCookies.addEventListener("click", () => {
    sessionStorage.setItem("cookieChoice", "declined")
    hideCookieBanner()
    console.log("Cookies declined")
  })

  // Smooth Scrolling for Anchor Links
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      const href = this.getAttribute("href")
      if (href !== "#" && href !== "") {
        e.preventDefault()
        const target = document.querySelector(href)
        if (target) {
          target.scrollIntoView({
            behavior: "smooth",
            block: "start",
          })
        }
      }
    })
  })
})
