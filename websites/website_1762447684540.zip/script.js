// Mobile Menu Toggle
const mobileMenuToggle = document.querySelector(".mobile-menu-toggle")
const navMenu = document.querySelector(".nav-menu")

if (mobileMenuToggle) {
  mobileMenuToggle.addEventListener("click", () => {
    navMenu.classList.toggle("active")
    mobileMenuToggle.classList.toggle("active")
  })
}

// Cookie Banner Functionality
const cookieBanner = document.getElementById("cookieBanner")
const acceptCookies = document.getElementById("acceptCookies")
const declineCookies = document.getElementById("declineCookies")

// Show cookie banner on every page load (no localStorage check)
if (cookieBanner) {
  cookieBanner.classList.add("show")
}

// Accept cookies
if (acceptCookies) {
  acceptCookies.addEventListener("click", () => {
    cookieBanner.classList.remove("show")
    console.log("Cookies accepted")
  })
}

// Decline cookies
if (declineCookies) {
  declineCookies.addEventListener("click", () => {
    cookieBanner.classList.remove("show")
    console.log("Cookies declined")
  })
}

// Newsletter Form
const newsletterForm = document.getElementById("newsletterForm")
if (newsletterForm) {
  newsletterForm.addEventListener("submit", (e) => {
    e.preventDefault()
    const email = newsletterForm.querySelector('input[type="email"]').value
    alert(`Thank you for subscribing with: ${email}`)
    newsletterForm.reset()
  })
}

// Smooth Scrolling
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    e.preventDefault()
    const target = document.querySelector(this.getAttribute("href"))
    if (target) {
      target.scrollIntoView({
        behavior: "smooth",
        block: "start",
      })
    }
  })
})

// Add animation on scroll
const observerOptions = {
  threshold: 0.1,
  rootMargin: "0px 0px -50px 0px",
}

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = "1"
      entry.target.style.transform = "translateY(0)"
    }
  })
}, observerOptions)

// Observe article cards and category cards
document.addEventListener("DOMContentLoaded", () => {
  const animatedElements = document.querySelectorAll(".article-card, .category-card")
  animatedElements.forEach((el) => {
    el.style.opacity = "0"
    el.style.transform = "translateY(20px)"
    el.style.transition = "opacity 0.6s ease, transform 0.6s ease"
    observer.observe(el)
  })
})
