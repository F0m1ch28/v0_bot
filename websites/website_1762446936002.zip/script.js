// Cookie Banner Management
document.addEventListener("DOMContentLoaded", () => {
  const cookieBanner = document.getElementById("cookieBanner")
  const acceptBtn = document.getElementById("acceptCookies")
  const declineBtn = document.getElementById("declineCookies")

  // Always show cookie banner on page load
  cookieBanner.classList.add("show")

  // Accept cookies
  acceptBtn.addEventListener("click", () => {
    cookieBanner.classList.remove("show")
    // In a real implementation, you would set cookies here
    console.log("Cookies accepted")
  })

  // Decline cookies
  declineBtn.addEventListener("click", () => {
    cookieBanner.classList.remove("show")
    // In a real implementation, you would handle declined cookies here
    console.log("Cookies declined")
  })

  // Mobile menu toggle
  const mobileMenuToggle = document.getElementById("mobileMenuToggle")
  const navMenu = document.getElementById("navMenu")

  if (mobileMenuToggle) {
    mobileMenuToggle.addEventListener("click", () => {
      navMenu.classList.toggle("active")
    })
  }

  // FAQ Accordion
  const faqQuestions = document.querySelectorAll(".faq-question")
  faqQuestions.forEach((question) => {
    question.addEventListener("click", function () {
      const faqItem = this.parentElement
      const isActive = faqItem.classList.contains("active")

      // Close all FAQ items
      document.querySelectorAll(".faq-item").forEach((item) => {
        item.classList.remove("active")
      })

      // Open clicked item if it wasn't active
      if (!isActive) {
        faqItem.classList.add("active")
      }
    })
  })

  // Newsletter form
  const newsletterForm = document.getElementById("newsletterForm")
  if (newsletterForm) {
    newsletterForm.addEventListener("submit", function (e) {
      e.preventDefault()
      const email = this.querySelector('input[type="email"]').value
      alert("Спасибо за подписку! Мы отправим письмо на " + email)
      this.reset()
    })
  }

  // Animated counter for stats
  const statNumbers = document.querySelectorAll(".stat-number")
  const observerOptions = {
    threshold: 0.5,
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        const target = Number.parseInt(entry.target.getAttribute("data-target"))
        animateCounter(entry.target, target)
        observer.unobserve(entry.target)
      }
    })
  }, observerOptions)

  statNumbers.forEach((stat) => {
    observer.observe(stat)
  })

  function animateCounter(element, target) {
    let current = 0
    const increment = target / 50
    const timer = setInterval(() => {
      current += increment
      if (current >= target) {
        element.textContent = target.toLocaleString()
        clearInterval(timer)
      } else {
        element.textContent = Math.floor(current).toLocaleString()
      }
    }, 30)
  }

  // Blog filter functionality
  const filterButtons = document.querySelectorAll(".filter-btn")
  const articleCards = document.querySelectorAll(".article-card")

  filterButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const category = this.getAttribute("data-category")

      // Update active button
      filterButtons.forEach((btn) => btn.classList.remove("active"))
      this.classList.add("active")

      // Filter articles
      articleCards.forEach((card) => {
        if (category === "all" || card.getAttribute("data-category") === category) {
          card.style.display = "flex"
        } else {
          card.style.display = "none"
        }
      })
    })
  })

  // Initialize charts if on homepage
  if (document.getElementById("heroChart")) {
    initHeroChart()
  }
  if (document.getElementById("engagementChart")) {
    initEngagementChart()
  }
  if (document.getElementById("topicsChart")) {
    initTopicsChart()
  }
})

// Chart initialization functions
function initHeroChart() {
  const canvas = document.getElementById("heroChart")
  const ctx = canvas.getContext("2d")

  // Set canvas size
  canvas.width = canvas.offsetWidth
  canvas.height = canvas.offsetHeight

  // Simple line chart
  const data = [30, 45, 40, 55, 50, 65, 60, 75, 70, 85]
  const padding = 40
  const width = canvas.width - padding * 2
  const height = canvas.height - padding * 2
  const maxValue = Math.max(...data)

  // Draw grid
  ctx.strokeStyle = "rgba(255, 255, 255, 0.1)"
  ctx.lineWidth = 1
  for (let i = 0; i <= 5; i++) {
    const y = padding + (height / 5) * i
    ctx.beginPath()
    ctx.moveTo(padding, y)
    ctx.lineTo(canvas.width - padding, y)
    ctx.stroke()
  }

  // Draw line
  ctx.strokeStyle = "#00d4ff"
  ctx.lineWidth = 3
  ctx.beginPath()

  data.forEach((value, index) => {
    const x = padding + (width / (data.length - 1)) * index
    const y = canvas.height - padding - (value / maxValue) * height

    if (index === 0) {
      ctx.moveTo(x, y)
    } else {
      ctx.lineTo(x, y)
    }
  })

  ctx.stroke()

  // Draw points
  ctx.fillStyle = "#00d4ff"
  data.forEach((value, index) => {
    const x = padding + (width / (data.length - 1)) * index
    const y = canvas.height - padding - (value / maxValue) * height

    ctx.beginPath()
    ctx.arc(x, y, 4, 0, Math.PI * 2)
    ctx.fill()
  })
}

function initEngagementChart() {
  const canvas = document.getElementById("engagementChart")
  const ctx = canvas.getContext("2d")

  canvas.width = canvas.offsetWidth
  canvas.height = canvas.offsetHeight

  const data = [
    { month: "Янв", value: 1200 },
    { month: "Фев", value: 1900 },
    { month: "Мар", value: 1500 },
    { month: "Апр", value: 2200 },
    { month: "Май", value: 2800 },
    { month: "Июн", value: 3200 },
  ]

  const padding = 40
  const width = canvas.width - padding * 2
  const height = canvas.height - padding * 2
  const maxValue = Math.max(...data.map((d) => d.value))
  const barWidth = width / data.length - 10

  // Draw bars
  data.forEach((item, index) => {
    const barHeight = (item.value / maxValue) * height
    const x = padding + (width / data.length) * index + 5
    const y = canvas.height - padding - barHeight

    // Gradient
    const gradient = ctx.createLinearGradient(0, y, 0, canvas.height - padding)
    gradient.addColorStop(0, "#0066cc")
    gradient.addColorStop(1, "#00a8e8")

    ctx.fillStyle = gradient
    ctx.fillRect(x, y, barWidth, barHeight)

    // Labels
    ctx.fillStyle = "#666"
    ctx.font = "12px sans-serif"
    ctx.textAlign = "center"
    ctx.fillText(item.month, x + barWidth / 2, canvas.height - padding + 20)
  })
}

function initTopicsChart() {
  const canvas = document.getElementById("topicsChart")
  const ctx = canvas.getContext("2d")

  canvas.width = canvas.offsetWidth
  canvas.height = canvas.offsetHeight

  const data = [
    { label: "Аналитика", value: 35, color: "#0066cc" },
    { label: "Стратегия", value: 25, color: "#00a8e8" },
    { label: "Культура", value: 20, color: "#00d4ff" },
    { label: "Инструменты", value: 20, color: "#5eb3f6" },
  ]

  const centerX = canvas.width / 2
  const centerY = canvas.height / 2
  const radius = Math.min(centerX, centerY) - 40

  let currentAngle = -Math.PI / 2

  data.forEach((item) => {
    const sliceAngle = (item.value / 100) * Math.PI * 2

    // Draw slice
    ctx.beginPath()
    ctx.moveTo(centerX, centerY)
    ctx.arc(centerX, centerY, radius, currentAngle, currentAngle + sliceAngle)
    ctx.closePath()
    ctx.fillStyle = item.color
    ctx.fill()

    // Draw label
    const labelAngle = currentAngle + sliceAngle / 2
    const labelX = centerX + Math.cos(labelAngle) * (radius * 0.7)
    const labelY = centerY + Math.sin(labelAngle) * (radius * 0.7)

    ctx.fillStyle = "#fff"
    ctx.font = "bold 14px sans-serif"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText(item.value + "%", labelX, labelY)

    currentAngle += sliceAngle
  })

  // Draw legend
  let legendY = 20
  data.forEach((item) => {
    ctx.fillStyle = item.color
    ctx.fillRect(20, legendY, 15, 15)

    ctx.fillStyle = "#333"
    ctx.font = "12px sans-serif"
    ctx.textAlign = "left"
    ctx.fillText(item.label, 40, legendY + 11)

    legendY += 25
  })
}
