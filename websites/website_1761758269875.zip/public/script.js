// Mobile Menu Toggle
const menuToggle = document.getElementById("menuToggle")
const mainNav = document.getElementById("mainNav")

if (menuToggle && mainNav) {
  menuToggle.addEventListener("click", () => {
    menuToggle.classList.toggle("active")
    mainNav.classList.toggle("active")
  })

  // Close menu when clicking outside
  document.addEventListener("click", (e) => {
    if (!menuToggle.contains(e.target) && !mainNav.contains(e.target)) {
      menuToggle.classList.remove("active")
      mainNav.classList.remove("active")
    }
  })
}

// FAQ Accordion
const faqQuestions = document.querySelectorAll(".faq-question")

faqQuestions.forEach((question) => {
  question.addEventListener("click", () => {
    const faqItem = question.parentElement
    const isActive = faqItem.classList.contains("active")

    // Close all FAQ items
    document.querySelectorAll(".faq-item").forEach((item) => {
      item.classList.remove("active")
    })

    // Open clicked item if it wasn't active
    if (!isActive) {
      faqItem.classList.add("active")
    }
  })
})

// Contact Form Submission
const contactForm = document.getElementById("contactForm")
const formSuccess = document.getElementById("formSuccess")

if (contactForm) {
  contactForm.addEventListener("submit", (e) => {
    e.preventDefault()

    // Simulate form submission
    setTimeout(() => {
      contactForm.style.display = "none"
      formSuccess.style.display = "block"

      // Reset form after 5 seconds
      setTimeout(() => {
        contactForm.reset()
        contactForm.style.display = "flex"
        formSuccess.style.display = "none"
      }, 5000)
    }, 500)
  })
}

// Cookie Banner - Shows on EVERY page load
const cookieBanner = document.getElementById("cookieBanner")
const acceptCookies = document.getElementById("acceptCookies")
const declineCookies = document.getElementById("declineCookies")

// Always show cookie banner on page load
if (cookieBanner) {
  // Show banner after a short delay for better UX
  setTimeout(() => {
    cookieBanner.classList.add("show")
  }, 500)
}

// Handle Accept button
if (acceptCookies) {
  acceptCookies.addEventListener("click", () => {
    cookieBanner.classList.remove("show")
    console.log("Cookies accepted")
  })
}

// Handle Decline button
if (declineCookies) {
  declineCookies.addEventListener("click", () => {
    cookieBanner.classList.remove("show")
    console.log("Cookies declined")
  })
}

// News Card Hover Effect - Add subtle animation
const newsCards = document.querySelectorAll(".news-card")

newsCards.forEach((card) => {
  card.addEventListener("mouseenter", () => {
    card.style.transition = "all 0.3s ease"
  })
})

// Smooth Scroll for Anchor Links
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    const href = this.getAttribute("href")
    if (href !== "#" && href !== "") {
      e.preventDefault()
      const target = document.querySelector(href)
      if (target) {
        target.scrollIntoView({
          behavior: "smooth",
          block: "start",
        })
      }
    }
  })
})

// Add loading animation for images
const images = document.querySelectorAll("img")

images.forEach((img) => {
  img.addEventListener("load", () => {
    img.style.opacity = "0"
    img.style.transition = "opacity 0.3s ease"
    setTimeout(() => {
      img.style.opacity = "1"
    }, 50)
  })
})

// Header scroll effect
let lastScroll = 0
const header = document.querySelector(".header")

window.addEventListener("scroll", () => {
  const currentScroll = window.pageYOffset

  if (currentScroll > lastScroll && currentScroll > 100) {
    header.style.transform = "translateY(-100%)"
  } else {
    header.style.transform = "translateY(0)"
  }

  lastScroll = currentScroll
})
