"use client"

import  from "../public/script"

export default function SyntheticV0PageForDeployment() {
  return < />
}